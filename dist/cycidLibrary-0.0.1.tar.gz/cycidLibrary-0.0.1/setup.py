
from setuptools import setup, find_packages
from cycidLibrary import main
setup(
    name="cycidLibrary",
    version="0.0.1",
    author="none",
    desctiption="my own library project",
    url="https://github.com/cycid/python_adv_hw5",
    packages=find_packages()
)

